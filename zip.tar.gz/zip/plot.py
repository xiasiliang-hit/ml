
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn import svm
import pdb


testN = 15
samples = datasets.load_iris()

#print samples.data[0]
#pdb.set_trace()

#print(samples.data.shape)
#print(samples.target)
x = [0, 1]
xtext = ['linear regression', 'logistic regression']
y = [0.33, 0.404]


plt.scatter(x, y)
plt.xticks(x, xtext)
plt.xlabel("model")
plt.ylabel("precision")

plt.show()
